"""Validate delivered animation files and preservation of the approved model."""
import json, math, hashlib
from pathlib import Path

OUT = Path(__file__).resolve().parent
read = lambda name: json.loads((OUT / name).read_text(encoding='utf-8'))
model = read('nine_tailed_fox.bbmodel')
original = read('before_animations/nine_tailed_fox.bbmodel')
export = read('nine_tailed_fox.animation.json')
live = read('animation-validation.json')
expected = {'tail_low': (8, True), 'idle': (16, True), 'walk': (1.2, True),
            'run': (.65, True), 'sleep_down': (4.5, 'hold_on_last_frame'),
            'sleep_idle': (5, True)}
assert model['elements'] == original['elements']
assert model['groups'] == original['groups']
assert model['outliner'] == original['outliner']
for filename in ['nine_tailed_fox.geo.json', 'nine_tailed_fox.png']:
    assert (OUT / filename).read_bytes() == (OUT / 'before_animations' / filename).read_bytes()
assert len(model['animations']) == len(export['animations']) == 6
bone_names = {g['name'] for g in model['groups']}
for short, (length, loop) in expected.items():
    name = 'animation.nine_tailed_fox.' + short
    a = export['animations'][name]
    assert a['animation_length'] == length and a['loop'] == loop
    assert set(a['bones']) <= bone_names
    for bone in a['bones'].values():
        for channel, values in bone.items():
            assert channel in ['rotation', 'position', 'scale']
            if isinstance(values, dict):
                for time, value in values.items():
                    assert 0 <= float(time) <= length + .000001
                    assert len(value) == 3 and all(isinstance(v, (int, float)) and math.isfinite(v) for v in value)
            else:
                assert len(values) == 3 and all(math.isfinite(v) for v in values)
assert live['result'] == 'PASS' and live['sleep_transition_pose_error'] < .0001
result = {'result': 'PASS', 'animations': len(expected), 'cubes': len(model['elements']),
          'geometry_unchanged': True, 'rig_unchanged': True, 'uv_unchanged': True,
          'approved_texture_unchanged': True, 'valid_export_bone_bindings': True,
          'native_pose_samples': sum(c['samples'] for c in live['clips']),
          'minimum_native_y': min(c['minimum_y'] for c in live['clips']),
          'loop_seams_match': True, 'sleep_transition_matches': True,
          'minecraft_runtime_tested': False,
          'animation_sha256': hashlib.sha256((OUT / 'nine_tailed_fox.animation.json').read_bytes()).hexdigest()}
(OUT / 'animation-file-validation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
